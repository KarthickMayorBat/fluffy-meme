/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author karth
 */
public class FP extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String uname=request.getParameter("suname");
        String pwd=request.getParameter("spwd");
        try { 
  
          
            Connection con = databaseconnection.initializeDatabase();   
            //Statement st = con.createStatement();
            PreparedStatement st = con.prepareStatement("insert into student_login values(? , ? )");
            st.setString(1, uname);
            st.setString(2, pwd);
          
            
           
  
           
            st.executeUpdate(); 
  
           
            st.close(); 
            con.close(); 
  
           
             
           // out.println("success");
            out.println("<html><body><center><b>Successfully Inserted!!!"
                        + "</b><a href='login.html'>Click here to login page!!!<a></center></body></html>"); 
        } 
       
        catch (Exception e) { 
            //e.printStackTrace();
            out.println(e);
        } 
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
