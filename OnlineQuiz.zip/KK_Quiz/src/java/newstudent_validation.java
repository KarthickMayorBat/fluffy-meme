import java.io.IOException; 
import java.io.PrintWriter; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.Statement;
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 

@WebServlet("/InsertData") 
public class newstudent_validation extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
  
    @Override
    protected void doPost(HttpServletRequest request,  
HttpServletResponse response) 
        throws ServletException, IOException 
    { 
        PrintWriter out = response.getWriter();
        String uname=request.getParameter("suname");
        String pwd=request.getParameter("spwd");
        try { 
  
          
            Connection con = databaseconnection.initializeDatabase();   
            //Statement st = con.createStatement();
            PreparedStatement st = con.prepareStatement("insert into student_login values(? , ? )");
            st.setString(1, uname);
            st.setString(2, pwd);
          
            
           
  
           
            int x = st.executeUpdate(); 
            if(x == 1){
                response.sendRedirect("login.html");
            }
           
            st.close(); 
            con.close(); 
  
           
             
            out.println("success");
        } 
       
        catch (Exception e) { 
            //e.printStackTrace();
            out.println(e);
        } 
         
    } 
}